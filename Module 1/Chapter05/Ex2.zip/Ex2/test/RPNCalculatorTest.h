#ifndef __RPNCALCULATORTEST_H__
#define __RPNCALCULATORTEST_H__

#include <gtest/gtest.h>
#include <iostream>
using namespace std;

#include "RPNCalculator.h"


#endif /* __RPNCALCULATORTEST_H__ */
