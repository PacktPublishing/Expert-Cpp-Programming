#include <iostream>
#include <string>
#include <sstream>
#include <stack>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;

class RPNCalculator {
public:
	double evaluate(string);
};
