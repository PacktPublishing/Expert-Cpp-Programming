Before do
  puts "Perform any initializations required before every test case"
end

After do
  puts "Perform any cleanup required before every test case"
end
