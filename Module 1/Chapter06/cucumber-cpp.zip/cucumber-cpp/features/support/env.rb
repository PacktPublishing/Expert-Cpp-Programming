require 'aruba/api'

World(Aruba::Api)

