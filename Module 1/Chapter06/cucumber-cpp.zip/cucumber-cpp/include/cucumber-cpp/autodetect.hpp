#include "internal/defs.hpp"
#ifndef STEP_INHERITANCE
    #error No test framework found: please include a testing framework before autodetect.hpp or include generic.hpp
#endif
