#ifndef CUKE_MACROS_HPP_
#define CUKE_MACROS_HPP_

#include "RegistrationMacros.hpp"
#include "step/StepMacros.hpp"
#include "hook/HookMacros.hpp"

#endif /* CUKE_MACROS_HPP_ */
