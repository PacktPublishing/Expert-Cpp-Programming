This sample shows a few advanced features: tags and table arguments.

