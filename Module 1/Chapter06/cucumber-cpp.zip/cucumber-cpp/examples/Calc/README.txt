This was inspired by Cuke4Nuke Calc sample

