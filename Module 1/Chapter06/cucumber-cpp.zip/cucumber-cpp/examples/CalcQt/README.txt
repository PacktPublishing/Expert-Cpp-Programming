This sample shows how to test a QT GUI. The environment variable
CALCQT_STEP_DELAY allows to introduce delays in the step execution for
demo purposes (i.e. CALCQT_STEP_DELAY=100 ./BoostCalculatorQtSteps)

