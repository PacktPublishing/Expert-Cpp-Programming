/*
 * =====================================================================================
 *
 *       Filename:  Hello.h
 *
 *    Description:  This is a simple Hello Class
 *
 *        Version:  1.0
 *        Created:  03/26/2017 04:54:54 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jeganathan Swaminathan <jegan@tektutor.org>
 *   Organization:  <http://www.tektutor.org>
 *
 * =====================================================================================
 */

#include <iostream>
#include <string>
using namespace std;

class Hello {
public:
   string sayHello();
};
